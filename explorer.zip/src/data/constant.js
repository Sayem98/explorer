export const RPC = "https://main.aesbit.com";
export const CHAINID = "15136";
