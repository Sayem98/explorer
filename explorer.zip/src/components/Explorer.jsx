function Explorer() {
  return <div>Explorer</div>;
}

export default Explorer;
